import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import ContactListScreen from './ContactListScreen';
import DetailScreen from './DetailScreen';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('contacts');
  const [selectedContact, setSelectedContact] = useState(null);
  const contacts = [
    { id: 1, name: 'wildan', phone: '123-456-7890', avatar: 'https://i.pinimg.com/736x/18/52/b7/1852b7fd4f00dee6f4d4063a47c3cc9f.jpg' },
    { id: 2, name: 'alfian', phone: '987-654-3210', avatar: 'https://i.pinimg.com/564x/4c/b7/2b/4cb72bbafa1d56346dec5155c95bd02e.jpg' },
    { id: 3, name: 'abyan', phone: '555-555-5555', avatar: 'https://i.pinimg.com/736x/66/01/a4/6601a46f4b756ea99c5c685696de0ee7.jpg' },
    { id: 4, name: 'agung', phone: '111-222-3333', avatar: 'https://i.pinimg.com/564x/e2/01/91/e20191291560518333d223761edeac31.jpg' },
  ];

  const onSelectContact = (contact) => {
    setSelectedContact(contact);
    setCurrentScreen('detail');
  };

  const onCloseDetail = () => {
    setSelectedContact(null);
    setCurrentScreen('contacts');
  };

  return (
    <View style={styles.container}>
      {currentScreen === 'contacts' && (
        <ContactListScreen contacts={contacts} onSelectContact={onSelectContact} />
      )}
      {currentScreen === 'detail' && (
        <DetailScreen contact={selectedContact} onClose={onCloseDetail} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingTop: 40,
  },
});
