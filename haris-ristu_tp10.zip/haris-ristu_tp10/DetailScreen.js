import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Image } from 'react-native';

const DetailScreen = ({ contact, onClose }) => {
  return (
    <View style={styles.container}>
      <View style={styles.navbar}>
        <TouchableOpacity onPress={onClose} style={styles.navButton}>
          <Text style={styles.navButtonText}>Kembali</Text>
        </TouchableOpacity>
        <Text style={styles.navTitle}>Detail Kontak</Text>
        <View style={styles.navPlaceholder}></View>
      </View>
      <Image source={{ uri: contact.avatar }} style={styles.avatar} />
      <View style={styles.detailContainer}>
        <Text style={styles.detailLabel}>Nama:</Text>
        <Text style={styles.detailText}>{contact.name}</Text>
      </View>
      <View style={styles.detailContainer}>
        <Text style={styles.detailLabel}>Nomor Telepon:</Text>
        <Text style={styles.detailText}>{contact.phone}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingTop: 40,
  },
  navbar: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  navTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  navButton: {
    padding: 10,
  },
  navButtonText: {
    fontSize: 16,
    color: '#007AFF', // blue color
  },
  navPlaceholder: {
    width: 60, // adjust as needed
  },
  avatar: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
  detailContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  detailLabel: {
    fontWeight: 'bold',
    marginRight: 10,
  },
  detailText: {
    fontSize: 16,
    color: '#333',
  },
});

export default DetailScreen;
