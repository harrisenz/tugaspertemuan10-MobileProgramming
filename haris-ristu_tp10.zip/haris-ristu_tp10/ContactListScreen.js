import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Image } from 'react-native';

const ContactListScreen = ({ contacts, onSelectContact }) => {
  return (
    <View style={styles.container}>
      <View style={styles.navbar}>
        <Text style={styles.navTitle}>Daftar Kontak</Text>
        <View style={styles.navPlaceholder}></View>
      </View>
      {contacts.map(contact => (
        <TouchableOpacity
          key={contact.id}
          style={styles.contactItem}
          onPress={() => onSelectContact(contact)}
        >
          <Image source={{ uri: contact.avatar }} style={styles.avatarSmall} />
          <View style={styles.contactInfo}>
            <Text style={styles.contactName}>{contact.name}</Text>
          </View>
          <TouchableOpacity
            style={styles.detailButton}
            onPress={() => onSelectContact(contact)}
          >
            <Text style={styles.detailButtonText}>Detail</Text>
          </TouchableOpacity>
        </TouchableOpacity>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingTop: 40,
  },
  navbar: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  navTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  navPlaceholder: {
    width: 60, // adjust as needed
  },
  contactItem: {
    backgroundColor: '#f0f0f0',
    padding: 15,
    marginBottom: 10,
    borderRadius: 10,
    width: '100%',
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  avatarSmall: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  contactInfo: {
    flex: 1,
  },
  contactName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  detailButton: {
    backgroundColor: '#5cb85c',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 5,
  },
  detailButtonText: {
    color: 'white',
    fontSize: 14,
  },
});

export default ContactListScreen;
